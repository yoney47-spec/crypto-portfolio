"""
チE��トデータ生�Eスクリプト
パフォーマンスチE��ト用に大量�EチE��ースを生成すめE
"""

import sqlite3
from datetime import datetime, timedelta
import random
from pathlib import Path

DB_PATH = Path(__file__).parent / "crypto_portfolio.db"

def generate_test_transactions(num_transactions=1000):
    """
    大量�EチE��ト取引データを生戁E
    
    Args:
        num_transactions: 生�Eする取引数�E�デフォルチE 1000件�E�E
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # 登録されてぁE��賁E��を取征E
        cursor.execute("SELECT id, symbol FROM assets")
        assets = cursor.fetchall()
        
        if not assets:
            print("[ERROR] 賁E��が登録されてぁE��せん。�Eに賁E��を登録してください、E)
            return
        
        asset_ids = [asset[0] for asset in assets]
        
        print(f"[INFO] {len(assets)}種類�E賁E��に対して{num_transactions}件の取引を生�EしまぁE..")
        
        # チE��ト取引を生�E
        start_date = datetime(2020, 1, 1)
        transaction_types = ['Buy', 'Sell', 'Airdrop', 'Staking Reward', 'Interest', 'Gift']
        
        generated_count = 0
        
        for i in range(num_transactions):
            # ランダムな日時生成！E020年�E�現在�E�E
            days_offset = random.randint(0, 1460)  # 紁E年刁E
            hours_offset = random.randint(0, 23)
            minutes_offset = random.randint(0, 59)
            
            trans_date = start_date + timedelta(
                days=days_offset,
                hours=hours_offset,
                minutes=minutes_offset
            )
            
            # ランダムな賁E��選抁E
            asset_id = random.choice(asset_ids)
            
            # ランダムな取引タイチE
            trans_type = random.choice(transaction_types)
            
            # ランダムな数量（賁E��によって異なるスケール�E�E
            if trans_type in ['Airdrop', 'Staking Reward', 'Interest', 'Gift']:
                # コストゼロ取弁E
                quantity = random.uniform(0.01, 100)
                price = 0.0
            else:
                # Buy/Sell
                quantity = random.uniform(0.001, 10)
                # 現実的な価格篁E���E�E10 、E$50,000�E�E
                price = random.uniform(10, 50000)
            
            total = quantity * price
            
            # 取引を挿入
            cursor.execute("""
                INSERT INTO transactions 
                (date, type, asset_id, quantity, price_per_unit, total_amount, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                trans_date.strftime("%Y-%m-%d %H:%M:%S"),
                trans_type,
                asset_id,
                quantity,
                price,
                total,
                f"Test transaction #{i+1}"
            ))
            
            generated_count += 1
            
            # 進捗表示
            if (i + 1) % 100 == 0:
                print(f"  進捁E {i+1}/{num_transactions} 件生�E...")
        
        conn.commit()
        print(f"\n[SUCCESS] {generated_count}件のチE��ト取引を生�Eしました�E�E)
        
        # 統計情報を表示
        cursor.execute("SELECT COUNT(*) FROM transactions")
        total_transactions = cursor.fetchone()[0]
        print(f"[INFO] チE�Eタベ�Eス冁E�E総取引数: {total_transactions}件")
        
    except Exception as e:
        conn.rollback()
        print(f"[ERROR] エラーが発生しました: {str(e)}")
    finally:
        conn.close()


def clear_test_transactions():
    """
    チE��ト取引データをクリア�E�注愁E 手動で追加した取引も削除されます！E
    """
    print("[WARNING] すべての取引データを削除しますか�E�E)
    confirm = input("続行するには 'yes' と入力してください: ")
    
    if confirm.lower() == 'yes':
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        try:
            cursor.execute("DELETE FROM transactions")
            conn.commit()
            print("[SUCCESS] すべての取引データを削除しました")
        except Exception as e:
            conn.rollback()
            print(f"[ERROR] 削除に失敗しました: {str(e)}")
        finally:
            conn.close()
    else:
        print("[CANCELLED] 削除をキャンセルしました")


if __name__ == "__main__":
    import sys
    
    print("=" * 60)
    print("チE��トデータ生�EチE�Eル")
    print("=" * 60)
    print()
    print("1. チE��ト取引を生�E (1000件)")
    print("2. チE��ト取引を生�E (5000件)")
    print("3. チE��ト取引を生�E (カスタム)")
    print("4. すべての取引データを削除")
    print("5. 終亁E)
    print()
    
    choice = input("選択してください (1-5): ")
    
    if choice == "1":
        generate_test_transactions(1000)
    elif choice == "2":
        generate_test_transactions(5000)
    elif choice == "3":
        try:
            num = int(input("生�Eする取引数を�E劁E "))
            if num > 0:
                generate_test_transactions(num)
            else:
                print("[ERROR] 正の整数を�E力してください")
        except ValueError:
            print("[ERROR] 無効な入力でぁE)
    elif choice == "4":
        clear_test_transactions()
    elif choice == "5":
        print("終亁E��まぁE)
    else:
        print("[ERROR] 無効な選択でぁE)
