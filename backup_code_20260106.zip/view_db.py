"""
チE�Eタベ�Eスの冁E��を確認するユーチE��リチE��スクリプト
"""

import sqlite3
from database import DB_PATH
import pandas as pd


def show_all_tables():
    """すべてのチE�Eブルの冁E��を表示する"""
    conn = sqlite3.connect(DB_PATH)
    
    print("=" * 80)
    print("チE�Eタベ�Eス冁E��確誁E)
    print("=" * 80)
    print()
    
    # チE�Eブル一覧を取征E
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()
    
    for (table_name,) in tables:
        # セキュリチE��: チE�Eブル名�E検証
        if not table_name.replace('_', '').isalnum():
            print(f"⚠�E�E スキチE�E: 不正なチE�Eブル吁E'{table_name}'")
            continue
            
        print(f"\n【{table_name}、E)
        print("-" * 80)
        
        # 検証済みのチE�Eブル名を使用
        df = pd.read_sql_query(f"SELECT * FROM {table_name}", conn)
        
        if len(df) == 0:
            print("(チE�EタなぁE")
        else:
            print(df.to_string(index=False))
        
        print()
    
    conn.close()


def show_schema():
    """チE�Eタベ�Eススキーマを表示する"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("=" * 80)
    print("チE�Eタベ�EススキーチE)
    print("=" * 80)
    print()
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()
    
    for (table_name,) in tables:
        # セキュリチE��: チE�Eブル名�E検証 (英数字とアンダースコアのみ許可)
        if not table_name.replace('_', '').isalnum():
            print(f"⚠�E�E スキチE�E: 不正なチE�Eブル吁E'{table_name}'")
            continue
            
        print(f"\n【{table_name}、E)
        print("-" * 80)
        
        # 検証済みのチE�Eブル名を使用
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = cursor.fetchall()
        
        for col in columns:
            col_id, name, col_type, not_null, default_val, pk = col
            pk_str = " [PRIMARY KEY]" if pk else ""
            null_str = " NOT NULL" if not_null else ""
            default_str = f" DEFAULT {default_val}" if default_val else ""
            print(f"  {name}: {col_type}{pk_str}{null_str}{default_str}")
        
        print()
    
    conn.close()


if __name__ == "__main__":
    show_schema()
    show_all_tables()
